MarketLink DZ V11 — Admin Delivered + Retour

هذه النسخة تصلح مشكلة أن Admin كان يشوف Delivered فقط بدون زر Retour.

التحديثات:
- في جدول إدارة الطلبيات الرئيسي يظهر الآن:
  - ✅ Delivered
  - ↩️ Retour
- Retour يطلب سبب الإرجاع.
- سبب الإرجاع يسجل في return_reason.
- تاريخ الإرجاع يسجل في returned_at.
- Delivered وRetour يستعملان RPC محمية من Supabase، وAdmin فقط يقدر ينفذهم.
- Supplier لا يستطيع تأكيد Delivered أو Retour.
- الطلبية المرتجعة لا تدخل عمولة للمسوق.

طريقة التركيب:
1. استبدل index.html في Netlify بالملف الموجود هنا.
2. افتح Supabase > SQL Editor.
3. شغل كامل ملف SUPPLIER_PRODUCT_V2_DELETE.sql.
4. سجل الدخول بحساب Admin.
5. جرّب طلبية حالتها "في التوصيل".
6. لازم تشوف زرين: Delivered و Retour.

اختبار Retour:
- اضغط ↩️ Retour.
- اكتب السبب.
- أكد العملية.
- الحالة تصبح "راجع".
- لا تُحسب عمولة للمسوق.
